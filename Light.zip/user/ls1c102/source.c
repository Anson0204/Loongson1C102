/*
 * source.c
 *
 * created: 2024/4/30
 *  author:
 */
#include "source.h"
#include "ls1x_uart.h"
#include "ls1c102_adc.h"
#include "ls1c102_ptimer.h"


//*******************UART_SendData**************************
void UART0_SendDataStr(uint8_t Data)
{
    Uart0_send(Data);
}
void UART1_SendDataStr(uint8_t Data)
{
    Uart1_send(Data);
}
void UART2_SendDataStr(uint8_t Data)
{
    Uart2_send(Data);
}
//****************************UART_Init********************
void UART0_InitStr(uint32_t buad)
{
    Uart0_init(buad);
}
void UART1_InitStr(uint32_t buad)
{
    Uart1_init(buad);
}
void UART2_InitStr(uint32_t buad)
{
    Uart2_init(buad);
}

//******************Send_String*****************************
void UART0_SendString(char *str)
{
    uint8_t i = 0;
    for(i = 0; str[i]!='\0'; i++)
    {
        uart0.SendData(str[i]);
    }
}
void UART0_SendStringNo0(char *str)
{
    uint8_t i = 0;
    for(i = 0; str[i]!='\0'; i++)
    {
        if(str[i] == 0)
        {
            break;
        }
        uart0.SendData(str[i]);
    }
}
void UART1_SendString(char *str)
{
    uint8_t i = 0;
    for(i = 0; str[i]!='\0'; i++)
    {
        uart1.SendData(str[i]);
    }
}
void UART2_SendString(char *str)
{
    uint8_t i = 0;
    for(i = 0; str[i]!='\0'; i++)
    {
        uart2.SendData(str[i]);
    }
}
void UART0_SendArry(uint8_t *Arry , uint8_t len)
{
    uint8_t i = 0;
    for(i = 0; i<len; i++)
    {
        uart0.SendData(Arry[i]);
    }
}
void UART1_SendArry(uint8_t *Arry, uint8_t len)
{
    uint8_t i = 0;
    for(i = 0; i<len; i++)
    {
        uart1.SendData(Arry[i]);
    }
}
struct UART0STR uart0 =
{
    .SendData          =           UART0_SendDataStr,
    .Initialze         =           UART0_InitStr,
    .SendString        =           UART0_SendString,
    .SendArry          =           UART0_SendArry,
    .SendStrNo0        =           UART0_SendStringNo0
};
struct UART1STR uart1 =
{
    .SendData          =           UART1_SendDataStr,
    .Initialze         =           UART1_InitStr,
    .SendString        =           UART1_SendString,
    .SendArry         =            UART1_SendArry
};
struct UART2STR uart2 =
{
    .SendData          =           UART2_SendDataStr,
    .Initialze         =           UART2_InitStr,
    .SendString        =           UART2_SendString
};


//***********************TIM_Init********************************************
void timer_init(uint32_t msec)
{
    TIM_InitTypeDef TIM_InitStruct;
    TIM_StructInit(&TIM_InitStruct);
    TIM_InitStruct.TIME_STP =8000*msec;
    TIM_Init(&TIM_InitStruct);
}

void QueInit(Que *Que)
{
    memset(&Que , 0 ,sizeof(Que));
    Que->rear = Que->front = 0;
}
int Que_isFull(Que *Que)
{
    return (((Que->rear + 1) % MAX_LEN) == Que->front);
}
int Que_isEmpty(Que *Que)
{
    return (Que->front == Que->rear);
}
int Que_Enqueue(Que *Que , uint8_t data)
{
    if(Que_isFull(Que))
    {
        return -1;
    }
    Que->dat[Que->rear] = data ;
    Que->rear = ((Que->rear + 1) % MAX_LEN);
    return 0;
}
int Que_Dequeue(Que *Que ,uint8_t *data)
{
    if(Que_isEmpty(Que))
    {
        return -1;
    }
    *data = Que->dat[Que->front];
    Que->dat[Que->front] = '\0';
    Que->front = ((Que->front + 1) % MAX_LEN);
    return 0;
}

int Que_Dequeue32Bit(Que *Que ,uint32_t *data)
{
    uint8_t dat ,flag;
    flag |= Que_Dequeue(Que ,&dat);
    flag <<= 1;
    *data |= (uint32_t)dat;
    
    flag |= Que_Dequeue(Que ,&dat);
    flag <<= 1;
    *data = ((*data << 8) | (uint32_t)dat);
    
    flag |= Que_Dequeue(Que ,&dat);
    flag <<= 1;
    *data = ((*data << 8) | (uint32_t)dat);
    
    flag |= Que_Dequeue(Que ,&dat);
    flag <<= 1;
    *data = ((*data << 8) | (uint32_t)dat);
    return (int)flag;
}


Que Rx1Que = {
    {0},
    0,
    0
};     //����1���ն���






