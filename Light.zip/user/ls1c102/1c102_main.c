#include "ls1x.h"
#include "Config.h"
#include "ls1x_spi.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ls1x_uart.h"
#include "source.h"
#include <string.h>
#include <stdlib.h>
#include "ls1c102_adc.h"
#include "ls1c102_i2c.h"
#include "ls1c102_interrupt.h"
#include "ls1c102_ptimer.h"

#define RADAR_THRESHOLD 1
#define PIR_THRESHOLD   1
#define LIGHT_A 75  // ������ֵA
#define NOEmpty 0
int timeaaa=0,aaaa=0;
long lx=0;
// UART0 RX 6 TX 7  115200
// UART1 RX 8 TX 9  9600
uint8_t Value[40];
uint8_t Value0[40];
uint8_t Data;
uint8_t RxBuffer[64] = {0};
int flag = 0,timea=0,pwm_cmp = 1, ring = 5;
char *strx;
extern int wcbz;
extern int wcbz0;
int valueZS=0,valueGM=0,valueZWX=0,valueRSD=0,valueAJ=0;
uint32_t integer_value;
char wd_value[20] = {0}, sd_value[12] = {0}, gz_value[12] = {0}, wbld_value[12] = {0}, rsd_value[12] = {0}, zwx_value[12] = {0}, qy_value[12] = {0}, zs_value[12] = {0}, sj[1024] = {0};
int yxzt=0;

void uart1dispose(void)
{
    while(wcbz == 1)    //����1 ���ݻ�ȡ������
    {
        if((Value[0] == 0xaa) && (Value[15] == 0xbb))
        {
            switch(Value[1])
            {
                case 0x01:
                    // �¶�
                    integer_value = (Value[2] << 24) | (Value[3] << 16) | (Value[4] << 8) | Value[5];
                    sprintf(wd_value, "%d", integer_value);
                    // ʪ��
                    integer_value = (Value[6] << 24) | (Value[7] << 16) | (Value[8] << 8) | Value[9];
                    sprintf(sd_value, "%d", integer_value);
                    // ����ǿ��
                    integer_value = (Value[10] << 24) | (Value[11] << 16) | (Value[12] << 8) | Value[13];
                    lx=integer_value;
                    sprintf(gz_value, "%d", integer_value);
                    break;

                case 0x02:
                    // ΢���״�
                    integer_value = (Value[2] << 24) | (Value[3] << 16) | (Value[4] << 8) | Value[5];
                    sprintf(wbld_value, "%d", integer_value);
                    // ��ѹ
                    integer_value = (Value[6] << 24) | (Value[7] << 16) | (Value[8] << 8) | Value[9];
                    sprintf(qy_value, "%d", integer_value);
                    break;

                case 0x03:
                    // ����
                    integer_value = (Value[6] << 24) | (Value[7] << 16) | (Value[8] << 8) | Value[9];
                    sprintf(zs_value, "%d", integer_value);
                    break;
            }
            wcbz = 0;
            // ����΢���״�����͵粢����GPIO32��ƽ
            if(yxzt==0)
            {

                if ((atoi(wbld_value) == RADAR_THRESHOLD || atoi(rsd_value) >= 4050) && lx <= LIGHT_A)
                {
                    gpio_write_pin(GPIO_PIN_33, 1);
                }
                else
                {
                    gpio_write_pin(GPIO_PIN_33, 0);
                }

                if (lx <= LIGHT_A)
                {
                    gpio_write_pin(GPIO_PIN_32, 1);
                }
                else
                {
                    gpio_write_pin(GPIO_PIN_32, 0);
                }
            }
        }
    }
}

void uart0dispose(void)
{
    while(wcbz0 == 1)    //����0
    {
        if((Value0[0] == 0xaa) && (Value0[3] == 0xbb))
        {
            // ��������
            switch (Value0[1])
            {
                case 0x00:
                    gpio_write_pin(GPIO_PIN_33, 0);
                    gpio_write_pin(GPIO_PIN_32, 0);
                    yxzt = 1;
                    break;
                case 0x01:
                    gpio_write_pin(GPIO_PIN_33, 0);
                    gpio_write_pin(GPIO_PIN_32, 1);
                    yxzt = 1;
                    break;
                case 0x02:
                    gpio_write_pin(GPIO_PIN_33, 1);
                    gpio_write_pin(GPIO_PIN_32, 1);
                    yxzt = 1;
                    break;
                case 0x03:
                    ring = 3;
                    break;
                case 0x04:
                    yxzt = 0;//�Զ�
                    break;
                default:
                    delay_ms(10);
            }
            uart0.SendString("ok");
        }
        wcbz0 = 0;
    }

}

void uart0Send(void)
{
    if(timea>=40)
    {                 //ƴ�Ӵ��������ݲ�����
        sprintf(sj,"{Temperation:%s,Humidity:%s,Light:%s,MicroWave_Radar:%s,PassiveInfrared:%d,Ultraviolet:%d,Atmospheric_Pressure:%s,Noise:%d,ring:%d}",
                wd_value,sd_value,gz_value,wbld_value,valueRSD,valueZWX,qy_value,valueZS,ring);
        uart0.SendString(sj);
        memset(sj, 0, sizeof(sj));
        timea=0;
    }
    timea++;
}
void uart0Sendbj(void)
{                   //ƴ�Ӵ��������ݲ�����
    sprintf(sj,"{Temperation:%s,Humidity:%s,Light:%s,MicroWave_Radar:%s,PassiveInfrared:%d,Ultraviolet:%d,Atmospheric_Pressure:%s,Noise:%d,ring:%d}",
            wd_value,sd_value,gz_value,wbld_value,valueRSD,valueZWX,qy_value,valueZS,ring);
    uart0.SendString(sj);
    memset(sj, 0, sizeof(sj));
}


void DIYUartInit(void)
{
    uart1.Initialze(9600);
    uart1.SendString("Boot OK");
    uart0.Initialze(115200);
    uart0.SendString("Boot OK");
    sprintf(wd_value, "999");
    sprintf(sd_value, "999");
    sprintf(gz_value, "999");
    sprintf(wbld_value,"999");
    sprintf(qy_value, "999");
}


void I2C11111(void)
{
    gpio_pin_remap(GPIO_PIN_4,GPIO_FUNC_MAIN);//���Ÿ���4��scl
    gpio_pin_remap(GPIO_PIN_5,GPIO_FUNC_MAIN);//���Ÿ���5��sda
    I2C_InitTypeDef I2C_InitStruct0;
    I2C_StructInit(&I2C_InitStruct0);
    I2C_Init(I2C, &I2C_InitStruct0);
    delay_ms(100);

}

void AdcOpenDoor(void)
{
    //AFIO_RemapConfig(AFIOB,GPIO_Pin_4,0);
    Adc_powerOn();//adc��Դ����
    Adc_open(ADC_CHANNEL_I1);
    Adc_open(ADC_CHANNEL_I4);
    Adc_open(ADC_CHANNEL_I6);
    Adc_open(ADC_CHANNEL_I7);
}
void Adcdispose(void)
{
    delay_ms(50);
    valueAJ=Adc_Measure(ADC_CHANNEL_I1);
    memset(sj, 0, sizeof(sj));
    if(valueAJ>=4090)
    {
        aaaa++;
    }
    if(ring !=1 && aaaa >= 4)
    {
        ring=1;
        aaaa=0;
        uart0Sendbj();//����0���;���
    }
    if(valueAJ<=4090&&aaaa!=0)
    {
        aaaa=0;
    }
    valueZS=Adc_Measure(ADC_CHANNEL_I4);
    valueZWX=Adc_Measure(ADC_CHANNEL_I6);
    valueRSD=Adc_Measure(ADC_CHANNEL_I7);
}


void BuzzerRing(void)
{
    if (valueAJ != 0)
    {
        timer_init(5);
        for(;;)
        {
            TIM_SetCompare1(13,pwm_cmp);
            TIM_SetCompare1(14,pwm_cmp - 10);
            pwm_cmp += 1;
            if(pwm_cmp > 20)
                pwm_cmp = 1;
            gpio_write_pin(GPIO_PIN_28,1);
            delay_ms(100);
            gpio_write_pin(GPIO_PIN_28,0);
            delay_ms(100);
        }
    }
}

void fmq(void)
{
    if(timeaaa>=10)
    {
        ring=0;
        timeaaa=0;
    }
    for(int i =0 ; i<=200; i++)
    {
        gpio_write_pin(GPIO_PIN_28, 1);
        delay_us(400);
        gpio_write_pin(GPIO_PIN_28, 0);
        delay_us(400);
    }
    delay_ms(100);
    for(int i =0 ; i<=200; i++)
    {
        gpio_write_pin(GPIO_PIN_28, 1);
        delay_us(600);
        gpio_write_pin(GPIO_PIN_28, 0);
        delay_us(600);
    }
    delay_ms(100);
    timeaaa++;
}

int main(int arg, char *args[])
{
    QueInit(&Rx1Que);
    DIYUartInit();//��ʼ������
    AdcOpenDoor();//��ʼ��adc
    ring=0;
    while(1)
    {
        gpio_write_pin(GPIO_PIN_20, 1);
        Adcdispose();//��ȡADC����
        uart0dispose();//��������0
        uart1dispose();//��������1
        if(ring==1)
        {
            delay_ms(50);
            gpio_write_pin(GPIO_PIN_20, 0);
            delay_ms(50);
            fmq();
        }
        else
        {
            uart0Send();//����0���ʹ���������
            delay_ms(50);
            gpio_write_pin(GPIO_PIN_20, 0);
            delay_ms(50);
        }

    }
    return 0;
}

















